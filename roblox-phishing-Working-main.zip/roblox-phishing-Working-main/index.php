<?php
header("Location: https://www.roblox.com/");
exit;
?>